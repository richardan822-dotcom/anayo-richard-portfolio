import { describe, expect, it } from 'vitest';
import { bookingUrl } from '@/lib/booking';
import { caseStudies } from '@/data/caseStudies';

describe('Free call booking links', () => {
  it('links every case study to the existing Calendly appointment', () => {
    for (const study of caseStudies) {
      const url = new URL(bookingUrl(`case-study-${study.slug}`));
      expect(url.origin).toBe('https://calendly.com');
      expect(url.pathname).toBe('/anayorichard81/30min');
      expect(url.searchParams.get('utm_source')).toBe('portfolio');
      expect(url.searchParams.get('utm_content')).toBe(`case-study-${study.slug}`);
    }
  });
});