import { describe, expect, it } from 'vitest';
import { caseStudies, findCaseStudy } from '@/data/caseStudies';

describe('Case study content', () => {
  it('contains four ordered systems with no unapproved quotes', () => {
    expect(caseStudies.map(study => study.number)).toEqual(['01', '02', '03', '04']);
    for (const study of caseStudies) {
      expect(study.built.length).toBeGreaterThanOrEqual(3);
      expect(study.built.length).toBeLessThanOrEqual(4);
      expect(study.quote).toBeUndefined();
      expect(study.timeline).toBe('TODO');
    }
  });
  it('uses supplied screens for every case study without fabricating media', () => {
    for (const study of caseStudies) {
      if (study.slug === 'emeritus-clinical-solutions') {
        expect(study.hero?.src).toContain('emeritus-3.png');
        expect(study.images).toHaveLength(4);
      } else if (study.slug === 'serrani-properties') {
        expect(study.hero?.src).toContain('serrani-home_1.png');
        expect(study.images).toHaveLength(4);
        expect(study.screenSlots).toHaveLength(0);
      }
    }
    expect(findCaseStudy('camp-leader-portal')?.logo).toContain('minnetonka-logo-white.png');
    expect(findCaseStudy('unknown')).toBeUndefined();
  });
  it('includes the Camp branding, ordered screenshots and privacy note', () => {
    const camp = findCaseStudy('camp-leader-portal');
    expect(camp?.client).toBe('Minnetonka Christian Camp');
    expect(camp?.hero?.src).toContain('camp-login.png');
    expect(camp?.images.map(image => image.src.split('/').at(-1))).toEqual(['camp-login.png', 'camp-dashboard.png']);
    expect(camp?.images[1]?.scrollVertical).toBe(true);
    expect(camp?.galleryNote).toBe('Camper and leader details have been removed to protect confidential data.');
  });
  it('includes Kimball comparisons before the ordered portal gallery', () => {
    const study = findCaseStudy('kimball-studio');
    expect(study?.hero?.src).toContain('kimball-portal-home.png');
    expect(study?.comparisons).toHaveLength(2);
    expect(study?.images.map(image => image.src.split('/').at(-1))).toEqual(['kimball-portal-home.png', 'kimball-portal-makeups.png', 'kimball-portal-library.png']);
    expect(study?.built[0]?.description).toContain('Members see their upcoming classes, book makeups and open a learning library.');
  });
});