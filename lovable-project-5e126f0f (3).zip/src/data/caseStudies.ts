import serrani from '@/assets/serrani-properties.png.asset.json';
import emeritus from '@/assets/emeritus.png.asset.json';
import kimball from '@/assets/kimball-studio.png.asset.json';
import emeritusHub from '@/assets/emeritus-3.png.asset.json';
import emeritusSession from '@/assets/emeritus-2.png.asset.json';
import emeritusForm from '@/assets/emeritus-4.png.asset.json';
import emeritusData from '@/assets/emeritus-1.png.asset.json';
import campLogin from '@/assets/camp-login.png.asset.json';
import campDashboard from '@/assets/camp-dashboard.png.asset.json';
import kimballHome from '@/assets/kimball-portal-home.png.asset.json';
import kimballMakeups from '@/assets/kimball-portal-makeups.png.asset.json';
import kimballLibrary from '@/assets/kimball-portal-library.png.asset.json';
import kimballBeforeHome from '@/assets/kimball-before-home.png.asset.json';
import kimballBeforeAbout from '@/assets/kimball-before-about.png.asset.json';
import kimballAfterHome from '@/assets/kimball-after-home.png.asset.json';
import kimballAfterAbout from '@/assets/kimball-after-about.png.asset.json';
import campLogo from '@/assets/minnetonka-logo-white.png.asset.json';
import serraniHome from '@/assets/serrani-home_1.png.asset.json';
import serraniSignIn from '@/assets/serrani-signin_1.png.asset.json';
import serraniSync from '@/assets/serrani-sync_1.png.asset.json';
import serraniLateFee from '@/assets/serrani-latefee_1.png.asset.json';

export type CaseImage = { src: string; alt: string; caption: string; width: number; height: number; wide?: boolean; scrollVertical?: boolean };
export type CaseComparison = { before: CaseImage; after: CaseImage; caption: string };
export type CaseStudy = {
  number: string; slug: string; client: string; logo?: string; logoOnDark?: boolean; status: string;
  industry: string; services: string; stack: string[]; timeline: string;
  title: string; summary: string; problem: string;
  built: { title: string; description: string }[]; planned?: string;
  flow: string[]; sideTrack?: string; result: string; measuredResults?: string;
  hero?: CaseImage; images: CaseImage[]; screenSlots: string[];
  quote?: { text: string; attribution: string };
  comparisons?: CaseComparison[]; galleryNote?: string; heroCover?: boolean;
};

export const caseStudyContact = {
  upwork: 'https://www.upwork.com/freelancers/~01a9c1174fb11bd21d',
  email: 'mailto:anayorichard81@gmail.com',
};

const hub: CaseImage = { src: emeritusHub.url, alt: 'Emeritus field inventory hub listing active inventory sessions with filters; private details hidden', caption: 'The field hub. Each session is a visit to a hospital site, so teams can pick up where they left off.', width: 1525, height: 1920 };
const campSignIn: CaseImage = { src: campLogin.url, alt: 'Minnetonka Christian Camp leader portal sign in', caption: 'A branded sign in for Minnetonka Christian Camp group leaders.', width: 1920, height: 754 };
const memberHome: CaseImage = { src: kimballHome.url, alt: 'Kimball Studio member portal home screen', caption: 'The member home screen: upcoming classes, studio updates and one tap to cancel.', width: 1831, height: 1920 };
const propertyHome: CaseImage = { src: serraniHome.url, alt: 'Serrani Properties website homepage', caption: 'The existing Serrani Properties website, where tenants access the portal.', width: 1365, height: 1920, scrollVertical: true };

export const caseStudies: CaseStudy[] = [
  {
    number: '01', slug: 'serrani-properties', client: 'Serrani Properties', logo: serrani.url,
    status: 'Built and tested', industry: 'Residential property management',
    services: 'Tenant portal, automation, custom balance engine',
    stack: ['Wix', 'Make', 'Python', 'Google Cloud', 'Google Sheets'], timeline: 'TODO',
    title: 'A tenant portal with a ledger that explains itself',
    summary: "Tenants sign in on the existing Wix site and get a clear, itemised statement of what they owe and why, built from the landlord's own payment spreadsheet.",
    problem: 'Rent payments and charges lived in a spreadsheet. To tell a tenant what they owed, someone had to work out which month each payment covered, keep late fees and other charges separate from rent, and explain it in a way the tenant could follow.',
    built: [
      { title: 'Tenant sign in on the existing site', description: 'Tenants sign in to view their own statement.' },
      { title: 'A balance engine that applies payments fairly', description: 'A Python service on Google Cloud applies each payment to the oldest unpaid month first and keeps late fees, attorney fees and other charges separate from rent.' },
      { title: 'A statement people can read', description: 'A clean statement with a plain English month by month explanation, older historical balances shown separately, and a PDF download.' },
      { title: 'Automation behind the scenes', description: 'Make scenarios sync balances on a schedule and handle billing steps so nothing is retyped.' },
    ],
    flow: ['Tenant signs in.', 'The portal requests their statement.', 'The engine reads the transaction sheet.', 'Payments are applied to the oldest month first and extra charges are kept apart.', 'The statement appears on screen and downloads as a PDF.'],
    sideTrack: 'Make runs the scheduled balance sync.',
    result: "The landlord's rules now live in the system, so every statement follows them the same way. The engine was refined over several rounds as real tenant cases came up, such as how late fees are separated and how older balances are labelled.",
    measuredResults: 'TODO', hero: propertyHome,
    images: [propertyHome,
      { src: serraniSignIn.url, alt: 'Serrani Properties account registration screen with private fields hidden', caption: 'Account registration on the existing site.', width: 1920, height: 978 },
      { src: serraniSync.url, alt: 'Serrani Properties Make synchronisation workflow with provider names hidden', caption: 'The Make scenario for syncing spreadsheet records and billing steps.', width: 1920, height: 751, wide: true },
      { src: serraniLateFee.url, alt: 'Serrani Properties late fee automation with provider names hidden', caption: 'A separate Make scenario for late fee billing steps.', width: 1920, height: 827, wide: true },
    ], screenSlots: [], galleryNote: 'Private account details and payment-provider names have been concealed.',
  },
  {
    number: '02', slug: 'emeritus-clinical-solutions', client: 'Emeritus Clinical Solutions', logo: emeritus.url,
    status: 'In testing with client', industry: 'Clinical equipment services', services: 'Web app, automation',
    stack: ['Softr', 'Airtable', 'Make', 'SharePoint'], timeline: 'TODO',
    title: 'Equipment tracking that works on the hospital floor',
    summary: "A mobile friendly app for logging biomedical equipment with photos and identifiers, with records syncing automatically to the company's SharePoint.",
    problem: 'Equipment across hospital sites needs one reliable record: what it is, where it is, whether it is in service and what it looks like. Without a shared system that information ends up in notes and spreadsheets.',
    built: [
      { title: 'Add Asset form', description: 'Fast entry with equipment ID, hospital ID, department and location guidance, and an in service toggle.' },
      { title: 'Scan to fill', description: 'Photograph the equipment plate to prefill details instead of typing.' },
      { title: 'Photos with every asset', description: '' },
      { title: 'Automatic SharePoint sync', description: "Make copies records and photos to the client's SharePoint site." },
    ],
    planned: 'Barcode scanning of manufacturer labels.',
    flow: ['Staff add an asset.', 'A photo of the plate prefills the fields.', 'The record and photos save.', 'Make syncs them to SharePoint.'],
    result: 'TODO', hero: hub,
    images: [hub,
      { src: emeritusForm.url, alt: 'Emeritus Add Asset form with serial plate photo, identifiers and location fields; private values hidden', caption: 'Adding a device takes one form: photograph the serial plate, enter or scan the ID, and save to the active session.', width: 1266, height: 1920 },
      { src: emeritusSession.url, alt: 'Emeritus assets in the current session, searchable and filterable by status; private details hidden', caption: 'Everything captured in the current session, searchable and filterable by status.', width: 1920, height: 1509 },
      { src: emeritusData.url, alt: 'Equipment database table with status, location and in service columns; private rows hidden', caption: 'Behind the scenes: every device lands in one structured database with its status, location and in service flag.', width: 1920, height: 618, wide: true },
    ], screenSlots: [],
  },
  {
    number: '03', slug: 'kimball-studio', client: 'Kimball Studio', logo: kimball.url, status: 'Live',
    industry: 'Acting school, NYC and Zoom', services: 'Member portal, website redesign',
    stack: ['Softr', 'Airtable', 'Wix'], timeline: 'TODO',
    title: 'From a members area to a website rebuilt around its classes',
    summary: 'A members portal for an acting studio, followed by a redesigned website on Wix with clearer pages, tidy redirects and buttons to buy classes.',
    problem: 'The studio needed a members area its actors could use, and later a website that explained its classes, teachers and pricing clearly without losing visitors who arrive through old links.',
    built: [
      { title: 'Members portal', description: 'Built on an existing Airtable database. Members see their upcoming classes, book makeups and open a learning library.' },
      { title: 'Redesigned pages on Wix', description: 'Home, about with expandable teacher bios and source links, intensives and rentals under a new header and footer.' },
      { title: 'Redirects', description: 'Retired pages forward to the right new page and old links keep working.' },
      { title: 'Class purchase buttons', description: 'Connected, with the whole site checked on mobile.' },
    ],
    flow: ['A visitor arrives from search or an old link.', 'They land on the right current page.', 'They read the classes and teacher bios.', 'They buy a class or get in touch.'],
    result: "Launched on the studio's live site after review by the client on desktop and mobile.",
    hero: memberHome,
    comparisons: [
      { before: { src: kimballBeforeHome.url, alt: 'Kimball Studio homepage before the redesign', caption: '', width: 1920, height: 1300 }, after: { src: kimballAfterHome.url, alt: 'Kimball Studio homepage after the redesign', caption: '', width: 1032, height: 1920 }, caption: 'Before: a photo hero with two big buttons. After: a plain page that explains the classes, how membership works and how to get in touch.' },
      { before: { src: kimballBeforeAbout.url, alt: 'Kimball Studio about page before the redesign', caption: '', width: 1920, height: 1300 }, after: { src: kimballAfterAbout.url, alt: 'Kimball Studio about page after the redesign', caption: '', width: 1189, height: 1920 }, caption: 'Before: a story block and instructor photos. After: teachers listed with their credentials up front and expandable full bios.' },
    ],
    images: [memberHome,
      { src: kimballMakeups.url, alt: 'Kimball Studio member portal makeup class reservations', caption: 'Members pick a makeup class and reserve it in one click.', width: 1920, height: 1185 },
      { src: kimballLibrary.url, alt: 'Kimball Studio member portal learning library', caption: 'A learning library of recorded classes, quick tips and worksheets.', width: 1919, height: 1679 },
    ], screenSlots: [], galleryNote: 'Member details have been removed to protect confidential data.',
  },
  {
    number: '04', slug: 'camp-leader-portal', client: 'Minnetonka Christian Camp', logo: campLogo.url, logoOnDark: true, status: 'Delivered',
    industry: 'Youth and church camps', services: 'Leader portal, filtering, handover',
    stack: ['Softr', 'Google Sheets'], timeline: 'TODO',
    title: 'Getting a camp portal ready for the season',
    summary: 'A portal where church group leaders look up their registrations by camp week and group, export them, and sign in without fuss.',
    problem: "Registrations lived in a Google Sheet, with a separate church group column for each camp week. Leaders needed to find their own group's campers quickly, and the portal had to be ready before camp season started.",
    built: [
      { title: 'A branded sign in', description: 'Simpler password rules for non technical leaders.' },
      { title: 'Two linked filters', description: 'Pick a camp week, then a church group. The table stays hidden until both are chosen, so leaders only see what they asked for.' },
      { title: 'Clear instructions and export', description: 'Plain instructions on the dashboard for a first visit, and a CSV export button for each filtered list.' },
      { title: 'A practical handover', description: 'The embed code and a step by step guide for changing the login image without a developer.' },
    ],
    flow: ['A leader signs in.', 'They pick a camp week.', 'They pick their church group.', "They see that group's registrations.", 'They export a CSV.'],
    result: 'Live for the camp season. After launch I fixed a filter that missed campers listed under week specific church group columns, and found that browsers block sign in inside embedded frames, so the portal now opens from a direct link. The client rated the project 5.0 on Upwork.',
    hero: campSignIn, heroCover: true,
    images: [campSignIn, { src: campDashboard.url, alt: 'Minnetonka Christian Camp leader portal dashboard', caption: 'Group leaders pick a camp week, then their church group, and the roster appears, ready to export as a CSV.', width: 1740, height: 1920, scrollVertical: true }], screenSlots: [],
    galleryNote: 'Camper and leader details have been removed to protect confidential data.',
  },
];

export function findCaseStudy(slug: string) { return caseStudies.find(study => study.slug === slug); }