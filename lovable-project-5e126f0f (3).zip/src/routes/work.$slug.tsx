import { createFileRoute, Link, notFound } from '@tanstack/react-router';
import { CaseStudyPage } from '@/components/case-study-page';
import { findCaseStudy } from '@/data/caseStudies';

export const Route = createFileRoute('/work/$slug')({
  loader: ({ params }) => {
    const study = findCaseStudy(params.slug);
    if (!study) throw notFound();
    return study;
  },
  head: ({ loaderData }) => {
    const title = loaderData ? `Case study: ${loaderData.title} | Anayo Richard` : 'Case study not found | Anayo Richard';
    const description = loaderData?.slug === 'camp-leader-portal' ? `${loaderData.client}: ${loaderData.summary}` : loaderData?.summary ?? 'This case study is not available. Browse the case studies from Anayo Richard.';
    return { meta: [
      { title }, { name: 'description', content: description },
      { property: 'og:title', content: title }, { property: 'og:description', content: description },
      { property: 'og:type', content: 'article' }, { name: 'twitter:card', content: 'summary_large_image' },
      ...(!loaderData ? [{ name: 'robots', content: 'noindex' }] : []),
    ] };
  },
  component: CaseStudyRoute,
  notFoundComponent: () => <main className="wrap case-unavailable"><h1>Case study not found</h1><Link to="/" hash="work">Back to case studies</Link></main>,
});

function CaseStudyRoute() {
  const study = Route.useLoaderData();
  return <CaseStudyPage key={study.slug} study={study} />;
}