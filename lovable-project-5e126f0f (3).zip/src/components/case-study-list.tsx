import { Link } from '@tanstack/react-router';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { caseStudies } from '@/data/caseStudies';
import { CaseLogo, CaseTitle, CaseReveal, ScreenshotPending } from './case-study-primitives';

export function CaseStudyList() {
  const reduced = useReducedMotion();
  return <section id="work" className="section work-section case-list"><div className="wrap">
    <CaseReveal><div className="section-heading"><div><div className="eyebrow">CASE STUDIES</div><h2>Built and <em>running</em></h2><p className="case-subtitle">Four real systems: what was broken, what I built, and how it works now.</p></div></div></CaseReveal>
    <div>{caseStudies.map((study, index) => <CaseReveal key={study.slug} index={index}>
      <Link to="/work/$slug" params={{ slug: study.slug }} className="case-row" aria-label={`Read the case study: ${study.title}`}>
        <motion.span className="case-number" {...(reduced ? {} : { layoutId: `case-number-${study.slug}` })} transition={{ duration: 0.4, ease: 'easeOut' }}>{study.number}</motion.span>
        <div className="case-row-content"><div className="case-row-meta"><CaseLogo study={study} /><span className="case-status"><span aria-hidden="true" />{study.status}</span></div>
          <motion.h3 {...(reduced ? {} : { layoutId: `case-title-${study.slug}` })} transition={{ duration: 0.4, ease: 'easeOut' }}><CaseTitle title={study.title} /></motion.h3>
          <p>{study.summary}</p><div className="case-row-bottom"><div className="tags">{study.stack.map(tag => <span className="tag" key={tag}>{tag}</span>)}</div><span className="case-read">Read the case study <ArrowRight aria-hidden="true" /></span></div>
        </div>
        <div className="case-row-preview" aria-hidden="true">{study.hero ? <img src={study.hero.src} alt="" loading="lazy" width={study.hero.width} height={study.hero.height} /> : <ScreenshotPending />}</div>
      </Link>
    </CaseReveal>)}</div>
  </div></section>;
}