import { useRef, useState, type PointerEvent } from 'react';
import { GripVertical } from 'lucide-react';
import type { CaseComparison } from '@/data/caseStudies';

export function CaseStudyComparison({ comparison }: { comparison: CaseComparison }) {
  const [position, setPosition] = useState(50);
  const dragging = useRef(false);
  function move(event: PointerEvent<HTMLInputElement>) {
    const bounds = event.currentTarget.getBoundingClientRect();
    if (bounds.width > 0) setPosition(Math.round(Math.max(0, Math.min(100, (event.clientX - bounds.left) / bounds.width * 100))));
  }
  return <figure className="case-comparison">
    <div className="comparison-frame">
      <img src={comparison.after.src} alt={comparison.after.alt} width={comparison.after.width} height={comparison.after.height} loading="lazy" />
      <img className="comparison-before" src={comparison.before.src} alt={comparison.before.alt} width={comparison.before.width} height={comparison.before.height} loading="lazy" style={{ clipPath: `inset(0 ${100 - position}% 0 0)` }} />
      <span className="comparison-chip comparison-chip-before">Before</span><span className="comparison-chip comparison-chip-after">After</span>
      <span className="comparison-handle" style={{ left: `${position}%` }} aria-hidden="true"><GripVertical /></span>
      <input type="range" min="0" max="100" value={position} onChange={event => setPosition(Number(event.target.value))} onPointerDown={event => { event.preventDefault(); event.currentTarget.focus(); event.currentTarget.setPointerCapture(event.pointerId); dragging.current = true; move(event); }} onPointerMove={event => { if (dragging.current) move(event); }} onPointerUp={event => { dragging.current = false; if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId); }} onPointerCancel={() => { dragging.current = false; }} aria-label={`Compare ${comparison.before.alt} and ${comparison.after.alt}`} aria-valuetext={`${position}% before, ${100 - position}% after`} className="comparison-range touch-none" />
    </div>
    <figcaption>{comparison.caption}</figcaption>
  </figure>;
}