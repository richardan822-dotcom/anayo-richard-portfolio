import { Link } from '@tanstack/react-router';
import { motion, useReducedMotion, useScroll } from 'framer-motion';
import { ArrowLeft, ArrowRight, ArrowUpRight, ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react';
import { useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import { caseStudies, caseStudyContact, type CaseStudy } from '@/data/caseStudies';
import { bookingUrl } from '@/lib/booking';
import { CaseLogo, CaseReveal, CaseTitle, DetailsPending, ScreenshotPending } from './case-study-primitives';
import { CaseStudyComparison } from './case-study-comparison';

function CaseFlow({ study }: { study: CaseStudy }) {
  const reduced = useReducedMotion();
  return <div className="case-flow"><ol>{study.flow.map((step, index) => <motion.li key={step} initial="waiting" whileInView="ready" viewport={{ once: true, amount: 0.4 }}>
    {index < study.flow.length - 1 && <motion.span aria-hidden="true" className="flow-line" variants={{ waiting: { scaleY: reduced ? 1 : 0 }, ready: { scaleY: 1 } }} transition={{ duration: reduced ? 0 : 0.4, delay: reduced ? 0 : index * 0.06, ease: 'easeOut' }} />}
    <motion.span className="flow-node" variants={{ waiting: { opacity: reduced ? 1 : 0.35 }, ready: { opacity: 1 } }} transition={{ duration: reduced ? 0 : 0.4, delay: reduced ? 0 : index * 0.06 }}><span>{String(index + 1).padStart(2, '0')}</span></motion.span><p>{step}</p>
  </motion.li>)}</ol>{study.sideTrack && <div className="flow-side-track"><span className="eyebrow">Scheduled automation</span><p>{study.sideTrack}</p></div>}</div>;
}

function CaseGallery({ study }: { study: CaseStudy }) {
  const [active, setActive] = useState<number | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);
  const image = active === null ? undefined : study.images[active];
  function advance(direction: number) { setActive(current => current === null ? null : (current + direction + study.images.length) % study.images.length); }
  return <><div className="case-gallery">{study.images.length ? study.images.map((item, index) => <figure key={item.src} className={item.wide ? 'is-wide' : item.scrollVertical ? 'is-tall' : undefined}>
    <Button variant="ghost" className="gallery-trigger" onClick={event => { triggerRef.current = event.currentTarget; setActive(index); }} aria-label={`Enlarge ${item.caption}`}><img src={item.src} alt={item.alt} width={item.width} height={item.height} loading="lazy" /><span className="gallery-zoom"><ZoomIn aria-hidden="true" /></span></Button><figcaption>{item.caption}</figcaption>
  </figure>) : study.screenSlots.map(caption => <figure key={caption}><ScreenshotPending /><figcaption>{caption}</figcaption></figure>)}</div>
    <Dialog open={active !== null} onOpenChange={open => { if (!open) setActive(null); }}><DialogContent className="case-lightbox" onCloseAutoFocus={event => { event.preventDefault(); triggerRef.current?.focus(); }} onKeyDown={event => { if (event.key === 'ArrowRight') { event.preventDefault(); advance(1); } if (event.key === 'ArrowLeft') { event.preventDefault(); advance(-1); } }}>
      <DialogTitle>{image?.caption ?? 'Screens'}</DialogTitle><DialogDescription className="sr-only">Case study screenshot. Private information has been hidden.</DialogDescription>
      {image && <img className="lightbox-image" src={image.src} alt={image.alt} width={image.width} height={image.height} />}
      <div className="lightbox-controls"><Button variant="portfolioOutline" size="icon" onClick={() => advance(-1)} aria-label="Previous screenshot"><ChevronLeft /></Button><span>{active === null ? '' : `${active + 1} / ${study.images.length}`}</span><Button variant="portfolioOutline" size="icon" onClick={() => advance(1)} aria-label="Next screenshot"><ChevronRight /></Button></div>
    </DialogContent></Dialog>
  </>;
}

export function CaseStudyPage({ study }: { study: CaseStudy }) {
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll();
  const currentIndex = caseStudies.findIndex(item => item.slug === study.slug);
  const next = caseStudies[(currentIndex + 1) % caseStudies.length];
  return <div className="case-page">
    <motion.div className="case-progress" style={{ scaleX: scrollYProgress }} aria-hidden="true" />
    <header className="case-header wrap"><Link to="/" hash="work" className="case-back"><ArrowLeft aria-hidden="true" />All case studies</Link><Link to="/" className="wordmark">Anayo Richard<span className="text-primary">.</span></Link></header>
    <main><motion.section className="case-hero wrap" initial={reduced ? false : { opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: reduced ? 0 : 0.4, ease: 'easeOut' }}>
      <div className="case-hero-meta"><motion.span className="case-number" {...(reduced ? {} : { layoutId: `case-number-${study.slug}` })} transition={{ duration: 0.4, ease: 'easeOut' }}>{study.number}</motion.span><CaseLogo study={study} /><span className="case-status"><span aria-hidden="true" />{study.status}</span></div>
      <motion.h1 {...(reduced ? {} : { layoutId: `case-title-${study.slug}` })} transition={{ duration: 0.4, ease: 'easeOut' }}><CaseTitle title={study.title} /></motion.h1><p className="case-lead">{study.summary}</p>
      <div className={`case-hero-image${study.heroCover ? ' case-hero-cover' : ''}`}>{study.hero ? <img src={study.hero.src} alt={study.hero.alt} width={study.hero.width} height={study.hero.height} fetchPriority="high" /> : <ScreenshotPending />}</div>
    </motion.section>
    <CaseReveal className="case-glance-band"><div className="wrap"><h2 className="eyebrow">At a glance</h2><dl className="case-glance">{[['Client', study.client], ['Industry', study.industry], ['What I built', study.services], ['Stack', study.stack.join(', ')], ['Timeline', study.timeline]].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value === 'TODO' ? <DetailsPending /> : value}</dd></div>)}</dl></div></CaseReveal>
    <div className="wrap case-story">
      <CaseReveal className="case-story-section"><h2>The <em>problem</em></h2><div><p>{study.problem}</p></div></CaseReveal>
      <CaseReveal className="case-story-section" index={1}><h2>What I <em>built</em></h2><div><div className="case-built">{study.built.map((item, index) => <CaseReveal key={item.title} index={index}><article><span className="eyebrow">0{index + 1}</span><h3>{item.title}</h3>{item.description && <p>{item.description}</p>}</article></CaseReveal>)}</div>{study.planned && <p className="case-planned"><strong>Planned next:</strong> {study.planned}</p>}</div></CaseReveal>
      <CaseReveal className="case-story-section" index={2}><h2>How it <em>works</em></h2><CaseFlow study={study} /></CaseReveal>
      <CaseReveal className="case-screens" index={3}><div className="case-section-heading"><h2><em>Screens</em></h2></div>{study.comparisons?.map(comparison => <CaseStudyComparison key={comparison.before.src} comparison={comparison} />)}<CaseGallery study={study} />{study.images.length > 0 && <p className="case-gallery-note">{study.galleryNote ?? 'Client identifiers have been blurred to protect confidential data.'}</p>}</CaseReveal>
      <CaseReveal className="case-story-section" index={4}><h2>The <em>result</em></h2><div>{study.result === 'TODO' ? <DetailsPending /> : <p>{study.result}</p>}{study.measuredResults && <div className="case-measured"><h3>Measured results</h3>{study.measuredResults === 'TODO' ? <DetailsPending /> : <p>{study.measuredResults}</p>}</div>}</div></CaseReveal>
      {study.quote && <CaseReveal className="case-story-section"><h2>Client <em>words</em></h2><figure><blockquote>{study.quote.text}</blockquote><figcaption>{study.quote.attribution}</figcaption></figure></CaseReveal>}
    </div>
    {next && <section className="case-next wrap"><div className="eyebrow">Next case study · {next.number}{next.slug === 'camp-leader-portal' ? ` · ${next.client}` : ''}</div>{next.slug === 'camp-leader-portal' && <CaseLogo study={next} />}<Link to="/work/$slug" params={{ slug: next.slug }}><h2><CaseTitle title={next.title} /></h2><ArrowRight aria-hidden="true" /></Link></section>}
    <section className="case-cta"><div className="wrap"><div><div className="eyebrow">Let's make it work</div><h2>Have a system to <em>build?</em></h2></div><div className="hero-actions"><Button asChild variant="portfolio" size="portfolio"><a href={bookingUrl(`case-study-${study.slug}`)} target="_blank" rel="noopener noreferrer">Book a free call <ArrowUpRight /></a></Button><Button asChild variant="portfolioOutline" size="portfolio"><a href={caseStudyContact.upwork} target="_blank" rel="noopener noreferrer">Hire me on Upwork <ArrowUpRight /></a></Button><Button asChild variant="portfolioOutline" size="portfolio"><a href={caseStudyContact.email}>Email me <ArrowUpRight /></a></Button></div></div></section>
    </main><footer className="wrap case-footer"><Link to="/">Anayo Richard</Link><span>© 2026 Anayo Richard</span></footer>
  </div>;
}