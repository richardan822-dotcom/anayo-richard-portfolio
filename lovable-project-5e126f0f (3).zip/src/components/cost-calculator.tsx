import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { bookingUrl } from '@/lib/booking';

function useCountUp(target: number) {
  const [value, setValue] = useState(target);
  const fromRef = useRef(target);
  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const from = fromRef.current;
    if (reduce || from === target) { setValue(target); fromRef.current = target; return; }
    let raf = 0; const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / 400); const eased = 1 - Math.pow(1 - t, 3);
      const v = from + (target - from) * eased; setValue(v); fromRef.current = v;
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target]);
  return value;
}

const fmt = (n: number) => Math.round(n).toLocaleString('en-US');
function N({ value, prefix = '' }: { value: number; prefix?: string }) {
  const v = useCountUp(value);
  return <>{prefix}{fmt(v)}</>;
}

type FieldProps = { id: string; label: string; value: number; onChange: (v: number) => void; min: number; max: number; step?: number; suffix?: string; helper?: string };
function Field({ id, label, value, onChange, min, max, step = 1, suffix, helper }: FieldProps) {
  const set = (raw: string) => { const n = Number(raw); onChange(Number.isFinite(n) ? Math.max(0, n) : 0); };
  return <div className="calc-field">
    <label htmlFor={id}>{label}</label>
    <div className="calc-input-row">
      <input type="range" aria-label={label} min={min} max={max} step={step} value={Math.min(value, max)} onChange={e => set(e.target.value)} />
      <div className="calc-number"><input id={id} type="number" inputMode="decimal" min={0} step={step} value={value} onChange={e => set(e.target.value)} />{suffix && <span>{suffix}</span>}</div>
    </div>
    {helper && <p className="calc-helper">{helper}</p>}
  </div>;
}

export function CostCalculator() {
  const [minutes, setMinutes] = useState(15);
  const [times, setTimes] = useState(10);
  const [people, setPeople] = useState(2);
  const [hourly, setHourly] = useState(30);
  const [percent, setPercent] = useState(70);
  const [budget, setBudget] = useState('');

  const p = percent / 100;
  const hoursPerYear = (minutes / 60) * times * people * 250;
  const costPerYear = hoursPerYear * hourly;
  const savedHours = hoursPerYear * p;
  const savedCost = costPerYear * p;
  const remainingHours = hoursPerYear - savedHours;
  const remainingCost = costPerYear - savedCost;
  const days = savedHours / 8;
  const budgetNum = Number(budget);
  const months = budget !== '' && budgetNum > 0 && savedCost > 0 ? budgetNum / (savedCost / 12) : null;
  const remainingPct = costPerYear > 0 ? (remainingCost / costPerYear) * 100 : 0;

  return <section id="calculator" className="section" aria-labelledby="calc-title"><div className="wrap reveal">
    <div className="section-heading"><div><div className="eyebrow">Your numbers</div><h2 id="calc-title">What manual work really <em>costs you</em></h2><p className="section-sub">Put in your own numbers. Nothing is saved or sent.</p></div></div>
    <div className="calc-layout">
      <div className="calc-inputs">
        <Field id="calc-minutes" label="Minutes per task" value={minutes} onChange={setMinutes} min={1} max={120} />
        <Field id="calc-times" label="Times per day" value={times} onChange={setTimes} min={1} max={100} />
        <Field id="calc-people" label="People doing it" value={people} onChange={setPeople} min={1} max={50} />
        <Field id="calc-hourly" label="Hourly cost" value={hourly} onChange={setHourly} min={5} max={200} suffix="$" />
        <Field id="calc-percent" label="How much of this could a system take over?" value={percent} onChange={v => setPercent(Math.min(100, v))} min={0} max={100} suffix="%" helper="Your estimate. We check what is realistic on the call." />
        <div className="calc-field"><label htmlFor="calc-budget">A budget you have in mind for a system, in dollars <span className="calc-optional">(optional)</span></label><div className="calc-number calc-budget"><span>$</span><input id="calc-budget" type="number" inputMode="decimal" min={0} value={budget} onChange={e => setBudget(e.target.value)} /></div></div>
      </div>
      <div className="calc-results" aria-live="polite">
        <div className="calc-cards">
          <div className="calc-card"><span className="calc-card-label">Doing it by hand</span><strong><N value={hoursPerYear} /> hrs</strong><span><N value={costPerYear} prefix="$" /> a year</span></div>
          <div className="calc-card is-highlight"><span className="calc-card-label">With a system</span><strong><N value={remainingHours} /> hrs</strong><span><N value={remainingCost} prefix="$" /> a year</span></div>
        </div>
        <div className="calc-bars" aria-hidden="true">
          <div className="calc-bar-row"><span>By hand</span><div className="calc-bar"><i style={{ width: costPerYear > 0 ? '100%' : '0%' }} /></div></div>
          <div className="calc-bar-row"><span>With a system</span><div className="calc-bar is-highlight"><i style={{ width: `${remainingPct}%` }} /></div></div>
        </div>
        <p className="calc-summary">You get back about <N value={savedHours} /> hours and <N value={savedCost} prefix="$" /> a year, about <N value={days} /> working days.</p>
        {months !== null && <p className="calc-summary is-secondary">A system at ${fmt(budgetNum)} would pay for itself in about {months < 1 ? months.toFixed(1) : fmt(months)} months.</p>}
        <p className="calc-fine">Hours per year = minutes ÷ 60 × times per day × people × 250 working days. Cost = hours × hourly cost. Saved = total × the share a system takes over.</p>
        <p className="calc-fine">This is an estimate based on the numbers you entered. It is not a promise of results.</p>
        <Button asChild variant="portfolio" size="portfolio"><a href={bookingUrl('calculator')} target="_blank" rel="noopener noreferrer">Book a call to get this time back <ArrowUpRight /></a></Button>
      </div>
    </div>
  </div></section>;
}
