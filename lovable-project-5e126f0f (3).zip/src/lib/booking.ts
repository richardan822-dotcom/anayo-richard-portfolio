export type BookingPlace = 'nav' | 'hero' | 'calculator' | 'call-steps' | 'faq' | 'closing' | 'mobile-bar' | `case-study-${string}`;
export const bookingUrl = (place: BookingPlace) => `https://calendly.com/anayorichard81/30min?utm_source=portfolio&utm_content=${place}`;
